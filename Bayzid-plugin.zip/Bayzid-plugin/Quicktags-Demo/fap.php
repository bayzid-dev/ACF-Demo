<h1>Hello World! This is first message from font-awesome preview</h1>

<button onclick="insertFA('fa fa-image')"> FA - IMAGE </button>
<button onclick="insertFA('fa fa-facebook')"> FA - FACEBOOK </button>
<button onclick="insertFA('fa fa-google')"> FA - GOOGLE </button>








