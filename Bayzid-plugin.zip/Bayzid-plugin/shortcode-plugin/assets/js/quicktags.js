QTags.addButton( 'shortcode_btn_one', "gmap", "[gmap place='Dhaka Museum']", "[/gmap]");
QTags.addButton( 'shortcode_btn_two', "button", "[button type='primary' title='Button Name' size='medium' url='https://']", "[/button]");
