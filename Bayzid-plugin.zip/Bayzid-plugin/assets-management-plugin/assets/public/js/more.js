;(function($){
    alert('Hello Word! From More.js');
})(jQuery)