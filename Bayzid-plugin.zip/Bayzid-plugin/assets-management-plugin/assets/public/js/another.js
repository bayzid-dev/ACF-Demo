;(function($){
    console.log(sitedata);
    alert(sitedata.Name + "\r\n" + sitedata.Email);


    // alert('This hello world is from another js');
})(jQuery)