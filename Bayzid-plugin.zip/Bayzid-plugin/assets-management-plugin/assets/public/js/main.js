;(function($){
    alert('Hello Word! From main js/jQuery ami jani na ki likhtam');
})(jQuery)