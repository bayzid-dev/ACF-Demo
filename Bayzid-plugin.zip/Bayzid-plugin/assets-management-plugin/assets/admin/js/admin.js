;(function($){
    $(document).ready(function () {
        alert('This message is from admin.js for WordPress backend page ');
    });
})(jQuery);