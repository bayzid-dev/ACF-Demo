;(function($){
    $(document).ready(function () {
        alert('This message is from admin-page.js for WordPress settings general options');
    });
})(jQuery);