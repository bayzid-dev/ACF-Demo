<?php
/**
 * Plugin Name: Assets Ninja
 * Plugin Uri: https://assets.ninja 
 * Description: Assets management in depth
 * Author: sejan ahmed bayzid
 * Version: 1.0
 * License: 
 * Text Domain: assetsninja
 * Domain path: 
 */


// common path
// define('ASN_ASSETS_DIR', plugin_dir_url(__FILE__) . 'assets/');
define('ASN_ASSETS_PUBLIC_DIR', plugin_dir_url(__FILE__) . 'assets/public/');
define('ASN_ASSETS_ADMIN_DIR', plugin_dir_url(__FILE__) . 'assets/admin');
define('ASN_VERSION', time());


class MyPlugin
{

  private $version; 

  public function __construct()
  {
    $this->version = time();  //cache-buster

    add_action('plugin_loaded', array($this, 'load_textdomain'));
    add_action('wp_enqueue_scripts', array($this, 'load_front_assets'));
    add_action('admin_enqueue_scripts', array($this, 'load_admin_script'));
  }

  function load_admin_script($screen){
    // for settings option-general
    if('options-general.php' == $screen){ // scaler value should be in left side
      wp_enqueue_script('asn-admin-page-js', ASN_ASSETS_ADMIN_DIR.'/js/admin-page.js');
    }

    // how to access specific script only on page/post by post_type checking
       $_screen = get_current_screen();
     if('edit.php' == $screen && 'page' == $_screen->post_type){
      wp_enqueue_script('asn-admin-js', ASN_ASSETS_ADMIN_DIR.'/js/admin.js');
     }
  }

  function load_front_assets()
  {
    //? CSS
    wp_enqueue_style('asn-main-css', ASN_ASSETS_PUBLIC_DIR.'/css/main.css'); // by default priority is 10

    //? JS
    wp_enqueue_script('asn-main-js', ASN_ASSETS_PUBLIC_DIR . '/js/main.js', array('jquery', 'asn-another-js'), $this->version, true);
    wp_enqueue_script('asn-another-js', ASN_ASSETS_PUBLIC_DIR . '/js/another.js', array('jquery'), $this->version, true);


  // array key => value to shorten the bigger enqueue line of code
  // $js_file = array(
  //   'asn-main-js'=>array('path'=> ASN_ASSETS_PUBLIC_DIR . '/js/main.js', 'dep'=>array('jQuery','asn-another-js')),
  //   'asn-another-js'=>array('path'=> ASN_ASSETS_PUBLIC_DIR . '/js/another.js', 'dep'=>array('jQuery'))
  // );
  // foreach($js_file as $handle=>$fileInfo){
  //   wp_enqueue_script($handle, $fileInfo['path'], $fileInfo['dep'], $this->version, true);
  // }

    //? accessing data from php to jQuery
    $data = array(
      'Name' => 'SeJan Ahmed BayZid',
      'Email' => 'bayziddev@gmail.com'
    );
    wp_localize_script('asn-another-js', 'sitedata', $data);
  }

 
  function load_textdomain(){
    load_plugin_textdomain('assetsninja', false, plugin_dir_url(__FILE__).'/languages');
  }

}
new MyPlugin();
